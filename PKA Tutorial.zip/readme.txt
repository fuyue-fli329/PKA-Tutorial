We will use Jupyter Notebook for the tutorial.
Please download Visual Studio Code (https://code.visualstudio.com/) to open the ".ipynb" file.

There are two parts:
1. Introduction. We will prepare for the simulation with some background information and software installation.
2. LAMMPS. We will dive into the simulation by conducting the PKA simulation for crystalline polyethylene.

Please read "Introduction.ipynb" before opening the "LAMMPS" folder.