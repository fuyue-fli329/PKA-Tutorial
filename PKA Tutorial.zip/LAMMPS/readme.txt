In this folder, it contains everything you need for the tutorial.

There are 5 subfolders:
1. Structure. We will learn how to create a unit cell for crystalline polyethylene.
2. Minimize. We will expand the unit cell and minimize the potential energy.
3. PKA. We will initiate a PKA and monitor the energy changes and trajectories.
4. Analysis. We will analyze the structural and chemical changes in detail.
5. PACE. We will run the same PKA simulation on PACE supercomputing clusters at Georgia Tech.

Please follow the order and read the ".ipynb" notebook in each subfolder carefully.